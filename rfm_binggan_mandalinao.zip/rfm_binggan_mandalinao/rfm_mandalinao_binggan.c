#include <stdio.h>
#include <math.h>

// Function declarations
double f(double x);
double f_prime(double x);
void falsePosition(double a, double b, int max_iter);
void newtonRaphson(double x0, int max_iter);

int main() {
    int choice, max_iter;
    double a, b, x0;
    char repeat;

    printf("=====================================================\n");
    printf("Root-Finding Program by Saint Joy A. Mandalinao\n");
    printf("This program finds the root of f(x) = -x^3 - 3x^2 + 2\n");
    printf("using either False Position or Newton-Raphson Method.\n");
    printf("=====================================================\n\n");

    do {
        printf("\nChoose which root finding method to use:\n");
        printf("1. False Position Method\n");
        printf("2. Newton-Raphson Method\n");
        printf("Enter choice [1 or 2]: ");
        scanf(" %d", &choice);

        printf("Enter maximum number of iterations: ");
        scanf(" %d", &max_iter);

        if (choice == 1) {
            printf("\n[False Position Method]\n");
            printf("Enter left endpoint a: ");
            scanf(" %lf", &a);
            printf("Enter right endpoint b: ");
            scanf(" %lf", &b);
            falsePosition(a, b, max_iter);
        } else if (choice == 2) {
            printf("\n[Newton-Raphson Method]\n");
            printf("Enter initial guess x0: ");
            scanf(" %lf", &x0);
            newtonRaphson(x0, max_iter);
        } else {
            printf("Invalid choice. Try again.\n");
        }

        printf("\nDo you want to try again? (y/n): ");
        scanf(" %c", &repeat);

    } while (repeat == 'y' || repeat == 'Y');

    printf("\nThank you for using the program. Goodbye!\n");
    return 0;
}

// Function definition
double f(double x) {
    return -pow(x, 3) - 3 * pow(x, 2) + 2;
}

double f_prime(double x) {
    return -3 * pow(x, 2) - 6 * x;
}

void falsePosition(double a, double b, int max_iter) {
    if (f(a) * f(b) >= 0) {
        printf("Invalid interval. f(a) * f(b) must be < 0.\n");
        return;
    }

    double c;
    for (int i = 0; i < max_iter; i++) {
        double fa = f(a), fb = f(b);
        double denominator = fb - fa;

        if (fabs(denominator) < 1e-12) {
            printf("Division by zero error in iteration %d. Exiting.\n", i);
            break;
        }

        c = (a * fb - b * fa) / denominator;
        double fc = f(c);

        printf("Iteration : %d Approx : %.7lf\n", i, c);
        printf("New interval is [ %.7lf , %.7lf ]\n", a, b);

        if (fabs(fc) < 1e-7)
            break;

        if (fa * fc < 0)
            b = c;
        else
            a = c;
    }
}

void newtonRaphson(double x0, int max_iter) {
    double x = x0;

    for (int i = 0; i < max_iter; i++) {
        double fx = f(x), fpx = f_prime(x);

        if (fabs(fpx) < 1e-12) {
            printf("Derivative near zero at iteration %d. Stopping.\n", i);
            break;
        }

        double x_new = x - fx / fpx;

        printf("Iteration : %d Approx : %.7lf\n", i, x);

        if (fabs(x_new - x) < 1e-7)
            break;

        x = x_new;
    }
}